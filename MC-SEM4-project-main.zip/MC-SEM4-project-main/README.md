# MC-SEM4-project

Overview 
The code snippet reads weather data from two CSV files, plots the average temperature for Seattle and Austin, and then plots the CO2 levels for the 1960s. It also defines a function to plot time series data and uses it to plot the CO2 levels and relative temperature. Finally, it sets different styles for the plots.
Input
	•	CSV file containing weather data for Seattle and Austin
Algorithm 
	1.	Read the weather data from the CSV files into pandas Data Frames.
	2.	Create a subplot and plot the average temperature for Seattle and Austin.
	3.	Set the x-axis label, y-axis label, and title for the plot.
	4.	Show the plot.
	5.	Create a 2x2 subplot and plot the precipitation for Seattle and Austin.
	6.	Show the plot.
	7.	Read climate change data from a CSV file, specifying the date column as a datetime and setting it as the index.
	8.	Select the data for the 1960s.
	9.	Create a subplot and plot the average temperature for Seattle and the CO2 levels for the 1960s.
	10.	Set the x-axis label, y-axis label, and title for the plot.
	11.	Show the plot.
	12.	Define a function to plot time series data.
	13.	Create a subplot and plot the CO2 levels and relative temperature using the defined function.
	14.	Show the plot.
	15.	Annotate the plot with an arrow and text.
	16.	Set the plot style to "ggplot".
	17.	Create a subplot and plot the average temperature for Seattle and Austin.
	18.	Set the x-axis label, y-axis label, and show the plot.
	19.	Set the plot style to "default", "bmh", "Solarize_Light2", and "seaborn-colorblind".

Outputs
	•	Plots of average temperature and precipitation for Seattle and Austin.
	•	Plot of average temperature for Seattle and CO2 levels for the 1960s.
	•	Plot of CO2 levels and relative temperature.
	•	Annotated plot with arrow and text.
	•	Plots of average temperature for Seattle and Austin with different plot styles.

