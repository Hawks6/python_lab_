import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

seattle_weather = pd.read_csv("MC SEM4 project\seattle_weather.csv")
austin_weather = pd.read_csv("MC SEM4 project\seattle_weather.csv")
seattle_weather.head()
fig, ax = plt.subplots()

ax.plot(seattle_weather["MONTH"], seattle_weather["MLY-TAVG-NORMAL"],marker="o", linestyle="None", color="r")
ax.plot(austin_weather["MONTH"], austin_weather["MLY-TAVG-NORMAL"],marker="v", linestyle="--")

ax.set_xlabel("Times (Months)")
ax.set_ylabel("Average temp (F degress)")
ax.set_title("Weather in Seattle")

plt.show()
fig, ax = plt.subplots(2, 2,sharey=True)
ax[0, 0].plot(seattle_weather['MONTH'], seattle_weather['MLY-PRCP-NORMAL'])
ax[1, 0].plot(austin_weather['MONTH'], austin_weather['MLY-PRCP-NORMAL'])
plt.show()
climate_change = pd.read_csv("climate_change.csv", parse_dates=["date"], index_col="date")

sixties = climate_change["1960-01-01":"1969-12-31"] 

fig, ax = plt.subplots()

ax.plot(seattle_weather.index, seattle_weather["MLY-TAVG-NORMAL"]) 
ax.plot(sixties.index, sixties['co2']) 

ax.set_xlabel("Times (Months)")
ax.set_ylabel("Average temp (F degress)")
ax.set_title("Weather in Seattle")

plt.show()
def plot_timeseries(axes, x, y, color, xlabel, ylabel):  
    axes.plot(x, y, color=color)  
    axes.set_xlabel(xlabel)  
    axes.set_ylabel(ylabel, color=color)  
    axes.tick_params('y', colors=color)

fig, ax = plt.subplots()

plot_timeseries(ax, climate_change.index, climate_change['co2'],'blue', 'Time', 'CO2 (ppm)')
ax2 = ax.twinx()
plot_timeseries(ax, climate_change.index,climate_change['relative_temp'],'red', 'Time','Relative temperature (Celsius)')
plt.show()

ax2.annotate(">1 degree", xy=(pd.Timestamp('2015-10-06'), 1), xytext=(pd.Timestamp('2008-10-06'), -0.2), arrowprops={"arrowstyle":"->", "color":"gray"})
plt.style.use("ggplot")

fig, ax = plt.subplots()
ax.plot(seattle_weather["MONTH"], seattle_weather["MLY-TAVG-NORMAL"])
ax.plot(austin_weather["MONTH"], austin_weather["MLY-TAVG-NORMAL"])
ax.set_xlabel("Time (months)")
ax.set_ylabel("Average temperature (Fahrenheit degrees)")
plt.show()

plt.style.use("default")
plt.style.use("bmh")
plt.style.use("Solarize_Light2")
plt.style.use("seaborn-colorblind")
